#### Run the following commands:
   1. Split your terminal screen into 2.
   
   2. On one side, run the server script with the root path as an argument:
   ```terminal
   python web_server.py "THE PATH TO THE FOLDER WHERE THIS FILE IS."
   ```
   3. on the other side i.e second terminal run web-browser script
   ```terminal
   python web_browser.py
   ```
### Django Files

#### File: `django.txt`
- **Location:** `/django/`

### Web Files

#### File: `web.txt`
- **Location:** `/web/`

### Postgres Files

#### File: `postgres.txt`
- **Location:** `/postgres/`

### Default File

#### File: `python.txt`
- **Location:** (If an invalid location is provided or direct path to those file is given)

Feel free to modify the URLs and examples based on your directory structure and naming conventions.